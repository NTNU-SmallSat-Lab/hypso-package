class DWProducts:
    Landsat8_USGS = "L8_USGS"
    Sentinel2_THEIA = "S2_THEIA"
    Sentinel2_ESA = "S2_S2COR"
    Sentinel2_L1C = "S2_L1C"